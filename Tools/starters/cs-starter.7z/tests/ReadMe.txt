Quick validation of answers
type A.in | GCJ.exe | cmp A.out

Don't use PS or 64-bit cmd, because of strange redirected output encoding, VS2012 x86 Native Tools prompt is the only option so far.